import Entity, { EntityConfig } from '../Entity';
import Subject from './Subject';
import Config from '../../lib/Config';
import PeriodController from '../../controllers/PeriodController';

export interface PeriodConfig extends EntityConfig {
    id: number
}

/**
 * Direct sibling: a period adjacent to another period, on the same day
 */
export default class Period extends Entity<PeriodConfig> {
    day() {
        const periodsPerDay =  Config.get('NUMBER_OF_PERIODS_PER_WEEK') / 5;
        return Math.floor(this.config.id / periodsPerDay);
    }
    
    offset(offset = 1) {
        return this.controller.get(this.config.id + offset);
    }

    offsetOrFail(offset = 1) {
        return this.controller.getOrFail(this.config.id + offset);
    }

    next(offset = 1) {
        return this.offset(offset);
    }

    previous(offset = 1) {
        return this.offset(-1 * offset);
    }
    
    getFreeAdjacentSiblings(periodSpan: number) {
        const directSiblings: Period[] = [];

        for (let i = -periodSpan; i < periodSpan; i++) {
            // Find the consecutive period, offset by i.
            // This also checks if the period is on the same day.
            const directSibling = this.getDirectSiblingOrFail(i);

            if(!directSibling) {
                break;
            }

            directSiblings.push(directSibling);
        }

        const freeDirectSiblings = directSiblings.reduce<Period[]>((acc, cur, i, arr) => {
            // End early when the required number
            // of free direct siblings is found
            if(acc.length >= periodSpan) {
                arr.splice(0);
            }

            if(cur.isFree()) {
                acc.push(cur);
            } else {
                // Reset `acc` when encountering an occupied periods
                acc = [];
            }

            return acc;
        }, []);

        return freeDirectSiblings;
    }

    getDirectSiblingOrFail(offset = 1) {
        const sibling = this.controller.getOrFail(this.config.id + offset);

        // Sibling is null if it exceeds the number of periods per week.
        // Also check if the periods are on the same day.
        if(!sibling || sibling.day() !== this.day()) {
            return null;
        }

        return sibling;
    }

    isFreeUntil(untilPeriod: Period) {
        let result = true;
        const indexDiff = Math.abs(untilPeriod.config.id - this.config.id);

        for (let i = 0; i < indexDiff; i++) {
            // Get the period that matches the current 'i'.
            const period = i === 0 ? this : this.controller.getOrFail(i);
            
            // Period is null when the id is not in the valid range
            if(!period || !period.isFree()) {
                result = false;
                break;
            }
        }

        return result;
    }

    isFree() {
        return this.getLinks(Subject).length === 0;
    }
}